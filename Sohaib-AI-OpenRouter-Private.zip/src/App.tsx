/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { TopBar } from './components/TopBar';
import { LandingPage } from './components/LandingPage';
import { ChatInterface } from './components/ChatInterface';
import { DeploymentGuideModal } from './components/DeploymentGuideModal';
import { LoginScreen } from './components/LoginScreen';

type AuthStatus = 'checking' | 'signed-in' | 'signed-out' | 'setup-error';

export default function App() {
  const [authStatus, setAuthStatus] = useState<AuthStatus>('checking');
  const [setupError, setSetupError] = useState<string | null>(null);
  const [currentView, setCurrentView] = useState<'landing' | 'chat'>(() => {
    if (typeof window !== 'undefined') {
      const params = new URLSearchParams(window.location.search);
      if (params.get('autostart') === '1' || params.get('view') === 'chat') return 'chat';
    }
    return 'landing';
  });
  const [initialChatPrompt, setInitialChatPrompt] = useState<string | undefined>(undefined);
  const [isDeploymentGuideOpen, setIsDeploymentGuideOpen] = useState<boolean>(false);

  const checkSession = async () => {
    try {
      const response = await fetch('/api/me', { credentials: 'same-origin' });
      const data = await response.json().catch(() => ({}));
      if (response.status === 503) {
        setSetupError(data.error || 'Server setup incomplete.');
        setAuthStatus('setup-error');
      } else {
        setSetupError(null);
        setAuthStatus(data.authenticated ? 'signed-in' : 'signed-out');
      }
    } catch {
      setSetupError('The server could not be reached. Make sure the Node.js app is running.');
      setAuthStatus('setup-error');
    }
  };

  useEffect(() => { void checkSession(); }, []);

  const handleStartChat = (prompt?: string) => {
    if (prompt) setInitialChatPrompt(prompt);
    setCurrentView('chat');
  };

  const handleLogout = async () => {
    try { await fetch('/api/logout', { method: 'POST', credentials: 'same-origin' }); } catch {}
    setAuthStatus('signed-out');
    setCurrentView('landing');
  };

  if (authStatus === 'checking') {
    return <div className="min-h-screen bg-slate-950 text-slate-300 flex items-center justify-center text-sm">Loading your private workspace…</div>;
  }
  if (authStatus !== 'signed-in') {
    return <LoginScreen setupError={authStatus === 'setup-error' ? setupError : null} onLogin={() => { setSetupError(null); setAuthStatus('signed-in'); }} />;
  }

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans selection:bg-amber-400 selection:text-slate-950">
      <TopBar
        currentView={currentView}
        onNavigate={(view) => setCurrentView(view)}
        onOpenDeploymentGuide={() => setIsDeploymentGuideOpen(true)}
        onNewChat={() => setCurrentView('chat')}
      />
      <div className="flex-1">
        {currentView === 'landing' ? (
          <LandingPage onStartChat={handleStartChat} onOpenDeploymentGuide={() => setIsDeploymentGuideOpen(true)} />
        ) : (
          <ChatInterface
            initialPrompt={initialChatPrompt}
            onClearInitialPrompt={() => setInitialChatPrompt(undefined)}
            onOpenDeploymentGuide={() => setIsDeploymentGuideOpen(true)}
            onNavigateHome={() => setCurrentView('landing')}
          />
        )}
      </div>
      <div className="fixed bottom-4 right-4 z-40">
        <button onClick={handleLogout} className="rounded-full border border-white/10 bg-slate-900/90 px-3 py-2 text-xs text-slate-300 shadow-lg backdrop-blur hover:border-amber-300/40 hover:text-amber-200">Sign out</button>
      </div>
      <DeploymentGuideModal isOpen={isDeploymentGuideOpen} onClose={() => setIsDeploymentGuideOpen(false)} />
    </div>
  );
}
