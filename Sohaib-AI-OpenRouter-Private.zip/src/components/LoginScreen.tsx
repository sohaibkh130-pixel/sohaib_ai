import React, { useState } from 'react';
import { LockKeyhole, Sparkles, LoaderCircle, AlertCircle } from 'lucide-react';

interface LoginScreenProps {
  onLogin: () => void;
  setupError?: string | null;
}

export const LoginScreen: React.FC<LoginScreenProps> = ({ onLogin, setupError }) => {
  const [password, setPassword] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  async function submit(event: React.FormEvent) {
    event.preventDefault();
    setError(null);
    setLoading(true);
    try {
      const response = await fetch('/api/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ password }),
      });
      const data = await response.json().catch(() => ({}));
      if (!response.ok) throw new Error(data.error || 'Login failed. Please try again.');
      setPassword('');
      onLogin();
    } catch (err: any) {
      setError(err?.message || 'Could not sign in. Check your connection.');
    } finally {
      setLoading(false);
    }
  }

  return (
    <main className="min-h-screen bg-slate-950 text-slate-100 flex items-center justify-center px-4 py-10">
      <div className="w-full max-w-md">
        <div className="rounded-3xl border border-white/10 bg-white/[0.04] p-7 sm:p-9 shadow-2xl shadow-black/30">
          <div className="mx-auto mb-6 flex h-14 w-14 items-center justify-center rounded-2xl border border-amber-300/20 bg-amber-300/10 text-amber-300">
            <Sparkles size={27} />
          </div>
          <div className="text-center">
            <p className="mb-2 text-xs font-semibold uppercase tracking-[0.28em] text-amber-300">Private workspace</p>
            <h1 className="text-3xl font-semibold tracking-tight">Sohaib AI</h1>
            <p className="mt-3 text-sm leading-6 text-slate-400">Sign in to open your personal AI assistant.</p>
          </div>

          {setupError ? (
            <div className="mt-7 rounded-xl border border-rose-400/20 bg-rose-400/10 p-4 text-sm leading-6 text-rose-200">
              <div className="mb-1 flex items-center gap-2 font-semibold"><AlertCircle size={16} /> Server setup needed</div>
              {setupError}
              <p className="mt-2 text-rose-100/80">Set APP_PASSWORD and SESSION_SECRET in the hosting environment, then restart the service.</p>
            </div>
          ) : (
            <form onSubmit={submit} className="mt-8 space-y-4">
              <label htmlFor="sohaib-password" className="block text-sm font-medium text-slate-300">Your private password</label>
              <div className="relative">
                <LockKeyhole className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-500" size={18} />
                <input
                  id="sohaib-password"
                  type="password"
                  autoComplete="current-password"
                  required
                  value={password}
                  onChange={(event) => setPassword(event.target.value)}
                  placeholder="Enter your password"
                  className="w-full rounded-xl border border-white/10 bg-slate-900/80 py-3.5 pl-11 pr-4 text-sm text-white outline-none transition placeholder:text-slate-600 focus:border-amber-300/50 focus:ring-2 focus:ring-amber-300/10"
                />
              </div>
              {error && <p role="alert" className="text-sm text-rose-300">{error}</p>}
              <button type="submit" disabled={loading || !password} className="flex w-full items-center justify-center gap-2 rounded-xl bg-amber-300 px-4 py-3.5 font-semibold text-slate-950 transition hover:bg-amber-200 disabled:cursor-not-allowed disabled:opacity-60">
                {loading ? <LoaderCircle size={18} className="animate-spin" /> : <LockKeyhole size={17} />}
                {loading ? 'Signing in…' : 'Unlock Sohaib AI'}
              </button>
            </form>
          )}
          <p className="mt-7 text-center text-xs leading-5 text-slate-500">Private sign-in · Your API key stays on the server</p>
        </div>
      </div>
    </main>
  );
};
